from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from openai import AsyncOpenAI
import json
import asyncio
from typing import Dict, List
import uuid
import httpx  # 添加这个导入

app = FastAPI(title="AI Chat API", version="1.0.0")

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该设置具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 天气数据库（模拟）
WEATHER_DATA = {
    "beijing": {"temp": "18℃", "condition": "晴天", "humidity": "45%"},
    "shanghai": {"temp": "22℃", "condition": "多云", "humidity": "60%"},
    "hangzhou": {"temp": "20℃", "condition": "晴天", "humidity": "50%"},
    "shenzhen": {"temp": "28℃", "condition": "高温", "humidity": "70%"},
    "chengdu": {"temp": "16℃", "condition": "阴天", "humidity": "55%"},
}

def get_weather(location):
    location_lower = location.lower()
    if location_lower in WEATHER_DATA:
        data = WEATHER_DATA[location_lower]
        return f"{location}天气：温度 {data['temp']}，{data['condition']}，湿度 {data['humidity']}"
    else:
        return f"抱歉，没有 {location} 的天气数据。支持的城市：{', '.join(WEATHER_DATA.keys())}"

async def execute_tool(tool_name, arguments_str):
    try:
        arguments = json.loads(arguments_str)
    except json.JSONDecodeError:
        return f"错误：无法解析参数: {arguments_str}"
    
    if tool_name == "get_weather":
        location = arguments.get("location", "")
        if not location:
            return "错误：缺少位置参数"
        return get_weather(location)
    return f"错误：未知工具 {tool_name}"

# 修复版本：创建自定义 HTTP 客户端
http_client = httpx.AsyncClient()

client = AsyncOpenAI(
    api_key="sk-a39471beda78451f83d3068fce622d08",
    base_url="https://api.deepseek.com/v1",
    http_client=http_client  # 使用自定义 HTTP 客户端
)

tools = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get weather of a location.",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {"type": "string", "description": "The city name, e.g. Beijing, Shanghai, must in English"}
                },
                "required": ["location"]
            },
        }
    }
]

# 会话管理
sessions: Dict[str, List[Dict]] = {}

def get_session_messages(session_id: str) -> List[Dict]:
    if session_id not in sessions:
        sessions[session_id] = [{
            "role": "system",
            "content": (
                "你是一个智能助手，具有以下功能：\n"
                "1. 可以调用 get_weather 工具查询城市天气信息\n"
                "2. 支持自然语言对话和回答用户问题\n"
                "请根据用户需求，灵活使用工具或直接回答问题。"
            )
        }]
    return sessions[session_id]

@app.get("/")
async def root():
    return {"message": "AI Chat API is running", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    await websocket.accept()
    
    try:
        while True:
            # 接收用户消息
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            if message_data['type'] == 'message':
                user_input = message_data['content']
                messages = get_session_messages(session_id)
                
                # 发送用户消息确认
                await websocket.send_json({
                    "type": "user_message_received",
                    "content": user_input
                })
                
                # 处理消息
                await process_message_streaming(websocket, user_input, messages)
                
    except WebSocketDisconnect:
        print(f"Client {session_id} disconnected")
        # 清理会话数据（可选）
        if session_id in sessions:
            del sessions[session_id]
    except Exception as e:
        print(f"Error: {e}")
        await websocket.close()

async def process_message_streaming(websocket: WebSocket, user_input: str, messages: List[Dict]):
    messages.append({"role": "user", "content": user_input})
    
    # 生成消息ID
    message_id = f"msg_{uuid.uuid4().hex[:8]}"
    
    # 第一次流式调用
    tool_calls_dict = {}
    content_buffer = ""
    
    try:
        response = await client.chat.completions.create(
            model="deepseek-chat",
            messages=messages,
            tools=tools,
            stream=True
        )
        
        # 通知前端开始接收助手消息
        await websocket.send_json({
            "type": "assistant_start",
            "messageId": message_id
        })
        
        # 第一阶段：收集工具调用和内容
        async for chunk in response:
            delta = chunk.choices[0].delta
            
            # 检测工具调用
            if delta.tool_calls:
                for tool_call in delta.tool_calls:
                    if tool_call.id:
                        tool_calls_dict[tool_call.index] = {
                            "id": tool_call.id,
                            "type": tool_call.type or "function",
                            "function": {"name": "", "arguments": ""}
                        }
                    
                    if tool_call.index in tool_calls_dict:
                        if tool_call.function:
                            if tool_call.function.name:
                                tool_calls_dict[tool_call.index]["function"]["name"] = tool_call.function.name
                            if tool_call.function.arguments:
                                tool_calls_dict[tool_call.index]["function"]["arguments"] += tool_call.function.arguments
            
            # 发送内容流
            if delta.content:
                content_buffer += delta.content
                await websocket.send_json({
                    "type": "assistant_chunk",
                    "messageId": message_id,
                    "content": delta.content
                })
        
        tool_calls = list(tool_calls_dict.values()) if tool_calls_dict else None
        
        # 如果有工具调用
        if tool_calls:
            # 添加assistant消息
            messages.append({
                "role": "assistant",
                "content": content_buffer if content_buffer else None,
                "tool_calls": tool_calls
            })
            
            # 通知工具调用开始
            await websocket.send_json({
                "type": "tool_calls_start",
                "tools": [{"name": tc["function"]["name"]} for tc in tool_calls]
            })
            
            # 执行所有工具调用
            for tool_call in tool_calls:
                tool_name = tool_call["function"]["name"]
                tool_args = tool_call["function"]["arguments"]
                tool_result = await execute_tool(tool_name, tool_args)
                
                # 发送工具调用信息
                await websocket.send_json({
                    "type": "tool_call",
                    "toolName": tool_name,
                    "toolResult": tool_result
                })
                
                # 添加tool消息
                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call["id"],
                    "name": tool_name,
                    "content": tool_result
                })
            
            # 第二次流式调用
            final_response = await client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                stream=True
            )
            
            final_message_id = f"msg_{uuid.uuid4().hex[:8]}"
            
            # 通知开始新的助手消息
            await websocket.send_json({
                "type": "assistant_start",
                "messageId": final_message_id
            })
            
            final_content = ""
            async for chunk in final_response:
                if chunk.choices[0].delta.content:
                    text = chunk.choices[0].delta.content
                    final_content += text
                    await websocket.send_json({
                        "type": "assistant_chunk",
                        "messageId": final_message_id,
                        "content": text
                    })
            
            # 保存最终回复
            messages.append({"role": "assistant", "content": final_content})
            
            # 结束消息
            await websocket.send_json({
                "type": "assistant_end",
                "messageId": final_message_id
            })
        else:
            # 没有工具调用，直接保存内容
            messages.append({"role": "assistant", "content": content_buffer})
            
            # 结束消息
            await websocket.send_json({
                "type": "assistant_end",
                "messageId": message_id
            })
            
    except Exception as e:
        print(f"Error in process_message_streaming: {e}")
        await websocket.send_json({
            "type": "error",
            "message": f"处理消息时出错: {str(e)}"
        })

# 添加关闭处理
@app.on_event("shutdown")
async def shutdown_event():
    await http_client.aclose()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
